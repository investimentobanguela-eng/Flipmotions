package com.flipmotion.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Ink = Color(0xFF10121A)
private val Panel = Color(0xFF1A1D29)
private val Purple = Color(0xFF9B7BFF)
private val Mint = Color(0xFF73E0C1)
private val Paper = Color(0xFFF7F6FC)

data class StrokeLine(val points: List<Offset>, val color: Color, val width: Float = 7f)
data class AnimationFrame(val strokes: List<StrokeLine> = emptyList())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FlipmotionApp() }
    }
}

@Composable
fun FlipmotionApp() {
    var frames by remember { mutableStateOf(listOf(AnimationFrame())) }
    var selectedFrame by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var selectedColor by remember { mutableStateOf(Color(0xFF20212B)) }
    var currentPoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var showExportMessage by remember { mutableStateOf(false) }
    val colors = listOf(Color(0xFF20212B), Color(0xFFEC6688), Color(0xFF9B7BFF), Color(0xFF2D9CDB), Color(0xFF28A879), Color(0xFFFFB84D))

    LaunchedEffect(playing, frames.size) {
        while (playing) {
            delay(140)
            selectedFrame = (selectedFrame + 1) % frames.size
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Purple,
        onBackground = Paper, onSurface = Paper
    )) {
        Column(
            Modifier.fillMaxSize().background(Ink).padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(Modifier.size(42.dp).background(Purple, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Text("F", color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("FLIPMOTION", fontSize = 19.sp, fontWeight = FontWeight.Black, color = Paper, letterSpacing = 1.5.sp)
                    Text("2D ANIMATION STUDIO", fontSize = 10.sp, color = Mint, letterSpacing = 1.7.sp)
                }
                TextButton(onClick = { showExportMessage = true }) { Text("EXPORT", color = Mint, fontWeight = FontWeight.Bold) }
            }

            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("My animation", color = Paper, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("${frames.size} frame${if (frames.size == 1) "" else "s"}  ·  7 FPS preview", color = Color.LightGray, fontSize = 12.sp)
                }
                Surface(color = Panel, shape = RoundedCornerShape(10.dp)) {
                    Text("  1:1  ", modifier = Modifier.padding(8.dp), color = Mint, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(12.dp))

            // Drawing stage
            Box(
                Modifier.fillMaxWidth().weight(1f).background(Color(0xFF252938), RoundedCornerShape(18.dp)).padding(10.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    Modifier.fillMaxSize()
                        .background(Paper, RoundedCornerShape(10.dp))
                        .pointerInput(selectedFrame, selectedColor, frames) {
                            detectDragGestures(
                                onDragStart = { start -> currentPoints = listOf(start) },
                                onDrag = { change, _ -> currentPoints = currentPoints + change.position },
                                onDragEnd = {
                                    if (currentPoints.isNotEmpty()) {
                                        val newFrame = frames[selectedFrame].copy(
                                            strokes = frames[selectedFrame].strokes + StrokeLine(currentPoints, selectedColor)
                                        )
                                        frames = frames.toMutableList().also { it[selectedFrame] = newFrame }
                                    }
                                    currentPoints = emptyList()
                                }
                            )
                        }
                ) {
                    // Subtle transparency grid
                    val step = 24.dp.toPx()
                    for (x in 0..(size.width / step).toInt()) {
                        for (y in 0..(size.height / step).toInt()) {
                            if ((x + y) % 2 == 0) drawRect(Color(0xFFF0EFF5), Offset(x * step, y * step), androidx.compose.ui.geometry.Size(step, step))
                        }
                    }
                    frames.getOrNull(selectedFrame)?.strokes?.forEach { line ->
                        if (line.points.size == 1) {
                            drawCircle(line.color, radius = line.width / 2, center = line.points.first())
                        } else {
                            val path = Path().apply {
                                moveTo(line.points.first().x, line.points.first().y)
                                line.points.drop(1).forEach { lineTo(it.x, it.y) }
                            }
                            drawPath(path, line.color, style = Stroke(width = line.width, cap = StrokeCap.Round))
                        }
                    }
                    if (currentPoints.isNotEmpty()) {
                        val path = Path().apply {
                            moveTo(currentPoints.first().x, currentPoints.first().y)
                            currentPoints.drop(1).forEach { lineTo(it.x, it.y) }
                        }
                        drawPath(path, selectedColor, style = Stroke(width = 7f, cap = StrokeCap.Round))
                    }
                }
                Text(
                    "FRAME ${selectedFrame + 1}",
                    modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp)
                        .background(Color(0xCCFFFFFF), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 4.dp),
                    color = Ink, fontSize = 10.sp, fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(14.dp))
            Text("BRUSH COLOR", color = Color.LightGray, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                colors.forEach { color ->
                    Box(
                        Modifier.size(30.dp).background(color, CircleShape)
                            .then(if (selectedColor == color) Modifier.border(3.dp, Paper, CircleShape) else Modifier)
                    ) {
                        Box(Modifier.fillMaxSize().pointerInput(color) {
                            awaitPointerEventScope {
                                while (true) {
                                    val event = awaitPointerEvent()
                                    if (event.changes.any { it.pressed }) selectedColor = color
                                }
                            }
                        })
                    }
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    frames = frames.toMutableList().also { it[selectedFrame] = AnimationFrame() }
                }) { Text("CLEAR", color = Color(0xFFFF8B9A), fontSize = 11.sp) }
            }

            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("TIMELINE", color = Paper, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
                Text("${selectedFrame + 1}/${frames.size}", color = Color.LightGray, fontSize = 12.sp)
            }
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                frames.forEachIndexed { index, frame ->
                    Surface(
                        onClick = { selectedFrame = index },
                        color = if (index == selectedFrame) Color(0xFF3A315B) else Panel,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.size(62.dp).border(if (index == selectedFrame) 2.dp else 1.dp, if (index == selectedFrame) Purple else Color(0xFF363949), RoundedCornerShape(10.dp))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Canvas(Modifier.fillMaxSize().padding(7.dp)) {
                                frame.strokes.forEach { line ->
                                    if (line.points.size > 1) {
                                        val path = Path().apply {
                                            moveTo(line.points.first().x * size.width / 300f, line.points.first().y * size.height / 500f)
                                            line.points.drop(1).forEach { lineTo(it.x * size.width / 300f, it.y * size.height / 500f) }
                                        }
                                        drawPath(path, line.color, style = Stroke(width = 2f, cap = StrokeCap.Round))
                                    }
                                }
                            }
                            Text("${index + 1}", modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp), color = Paper, fontSize = 9.sp)
                        }
                    }
                }
                Surface(onClick = {
                    frames = frames + AnimationFrame()
                    selectedFrame = frames.lastIndex
                    playing = false
                }, color = Panel, shape = RoundedCornerShape(10.dp), modifier = Modifier.size(62.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("+", fontSize = 30.sp, color = Mint)
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { selectedFrame = (selectedFrame - 1).coerceAtLeast(0); playing = false },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Paper)
                ) { Text("←") }
                Button(
                    onClick = { playing = !playing },
                    modifier = Modifier.weight(2f),
                    colors = ButtonDefaults.buttonColors(containerColor = Purple, contentColor = Ink)
                ) { Text(if (playing) "Ⅱ  PAUSAR" else "▶  REPRODUZIR", fontWeight = FontWeight.Black) }
                OutlinedButton(
                    onClick = { selectedFrame = (selectedFrame + 1).coerceAtMost(frames.lastIndex); playing = false },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Paper)
                ) { Text("→") }
            }
            Spacer(Modifier.height(6.dp))
            Text("Desenhe no quadro, adicione frames e reproduza sua animação.", color = Color.LightGray, fontSize = 11.sp)
        }

        if (showExportMessage) {
            AlertDialog(
                onDismissRequest = { showExportMessage = false },
                title = { Text("Exportação") },
                text = { Text("A interface de exportação está preparada para a próxima etapa. A exportação para GIF/MP4 ainda precisa ser implementada.") },
                confirmButton = {
                    TextButton(onClick = { showExportMessage = false }) { Text("ENTENDI") }
                },
                containerColor = Panel,
                titleContentColor = Paper,
                textContentColor = Color.LightGray
            )
        }
    }
}
