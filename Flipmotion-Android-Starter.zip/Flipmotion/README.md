# Flipmotion — Android 2D Animation Studio

MVP inicial em Kotlin + Jetpack Compose.

## Incluído
- Interface escura com identidade visual Flipmotion.
- Área de desenho por toque/arrasto.
- Seleção de cores de pincel.
- Limpeza do quadro atual.
- Timeline com seleção e criação de frames.
- Reprodução simples da sequência de frames.
- Botão de exportação com indicação transparente de que a exportação ainda será implementada.

## Abrir no Android Studio
1. Extraia o ZIP.
2. Abra a pasta `Flipmotion` no Android Studio (Hedgehog ou mais recente recomendado).
3. Aguarde a sincronização do Gradle.
4. Execute em um emulador ou dispositivo Android (API 26+).

## Limitações do protótipo
- Ainda não salva projetos entre sessões.
- Ainda não exporta GIF, MP4 ou PNG.
- O preview usa temporização simples; não há controle avançado de FPS.
- A miniatura da timeline é uma visualização básica.
- Undo/redo, camadas, onion skin e importação de imagens são próximos passos.

## Próximas etapas recomendadas
1. Persistência de projeto com Room/arquivos JSON.
2. Undo/redo por histórico de traços.
3. Onion skin para visualizar frames vizinhos.
4. Exportação de GIF e MP4.
5. Camadas, borracha, controle de tamanho do pincel e importação de imagem.

## Gerar APK pela nuvem (sem PC próprio)
O projeto inclui `.github/workflows/android-apk.yml`, que compila um APK de teste no GitHub Actions.

1. Crie uma conta no GitHub e um repositório vazio chamado `Flipmotion`.
2. Envie os arquivos desta pasta para o repositório (não envie o ZIP como único arquivo; envie o conteúdo extraído).
3. Abra a aba **Actions** do repositório e execute **Build Flipmotion APK** (Run workflow), ou faça um push para `main`.
4. Quando terminar, abra a execução concluída e baixe o artefato **Flipmotion-debug-APK**.
5. Extraia o ZIP do artefato e toque em `app-debug.apk` para instalar no Android. Talvez seja necessário autorizar a instalação para o navegador/gerenciador de arquivos.

Esse fluxo depende do GitHub e de uma conexão com a internet. O APK de debug serve para teste; não é uma versão assinada para publicação na Play Store.
